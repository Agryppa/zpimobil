package pl.edu.pwr.zpiclient;



public class Task {
    String taskName, startDate;
    private int status;

    public Task (String name, String date, int stat){
        taskName=name;
        startDate=date;
        status=stat;
    }


    public int getStatus() {
        return status;
    }

    public void setStatus(int newStatus){
        status=newStatus;
    }
}
