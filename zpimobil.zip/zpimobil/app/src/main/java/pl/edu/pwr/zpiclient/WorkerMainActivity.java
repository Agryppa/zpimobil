package pl.edu.pwr.zpiclient;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class WorkerMainActivity extends AppCompatActivity {
    private TextView workerName, position;
    private ImageView photo;
    private Button taskList,groupList,leaveList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_worker_main);
        setContent();
        setListeners();
    }

    private void setContent(){
        workerName=findViewById(R.id.workerNameText);
        position=findViewById(R.id.positionText);

        photo=findViewById(R.id.workerPhotoView);

        taskList=findViewById(R.id.taskListButton);
        groupList=findViewById(R.id.groupListButton);
        leaveList=findViewById(R.id.leaveListButton);
    }

    private void setListeners(){
        taskList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(WorkerMainActivity.this,WorkerTaskListActivity.class));
            }
        });

        groupList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(WorkerMainActivity.this,WorkerGroupListActivity.class));
            }
        });

        leaveList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(WorkerMainActivity.this,WorkerLeaveActivity.class));
            }
        });
    }
}
