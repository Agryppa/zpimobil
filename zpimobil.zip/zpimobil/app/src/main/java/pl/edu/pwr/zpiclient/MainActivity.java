package pl.edu.pwr.zpiclient;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.ResourceHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;


public class MainActivity extends AppCompatActivity {

    private RestTemplate rest = new RestTemplate();

    //private String url = "http://localhost:8090/api/";
    //z emulatora 10.0.2.2
    //private String url = "http://10.0.2.2:8090/";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

        StrictMode.setThreadPolicy(policy);

        try {
//
//            TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
//                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
//                    return null;
//                }
//
//                public void checkClientTrusted(X509Certificate[] certs, String authType) {
//                }
//
//                public void checkServerTrusted(X509Certificate[] certs, String authType) {
//                }
//            }
//            };
//
//            // Install the all-trusting trust manager
//            SSLContext sc = SSLContext.getInstance("SSL");
//            sc.init(null, trustAllCerts, new java.security.SecureRandom());
//
//            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
//
//            HostnameVerifier allHostsValid = new HostnameVerifier() {
//                public boolean verify(String hostname, SSLSession session) {
//                    return true;
//                }
//            };
//            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
//
//            URL url = new URL("https://10.0.2.2:8434");
//            URLConnection con = url.openConnection();
//
//


            final String uri = "https://10.0.2.2:8434/api/login";


            RestTemplate restTemplate = new RestTemplate();
            //RestTemplate restTemplate = new RestTemplate(new HttpComponentsClientHttpRequestFactory());


            restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
            restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
            restTemplate.getMessageConverters().add(new ResourceHttpMessageConverter());
            restTemplate.getMessageConverters().add(new FormHttpMessageConverter()); //to musi byc do logowania


            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

            MultiValueMap<String, String> map= new LinkedMultiValueMap<String, String>();
            map.add("username", "work");
            map.add("password", "worker1");

            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(map, headers);

            SSLUtil.turnOffSslChecking();
            String tmp = restTemplate.postForObject( uri, request , String.class);



            Toast.makeText(getApplicationContext(), tmp.toString(),Toast.LENGTH_SHORT).show();


        }catch(Exception e){
            Toast.makeText(getApplicationContext(), e.toString(),Toast.LENGTH_SHORT).show();
        }






        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Gość");
        setSupportActionBar(toolbar);
        RestTemplate rest = new RestTemplate();

        rest.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
        //rest.getForObject()
        // UserInfo.getInstance();



        final Button loginButton = findViewById(R.id.LoginButton);
        final TextView loginText = findViewById(R.id.LoginText);
        final TextView passwordText = findViewById(R.id.PassText);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //loginText.setText("");
                Worker temp = new Worker();
                temp.setLogin(loginText.getText().toString());
                temp.setPassword(passwordText.getText().toString());
                //Toast.makeText(MainActivity.this, temp.toString(), Toast.LENGTH_SHORT);

                Boolean ok = temp.getByLoginPassword();
                if(ok) {
                    //Toast.makeText(MainActivity.this, temp.getName(), Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(MainActivity.this, WorkerMainActivity.class));
                }else{
                    Toast.makeText(MainActivity.this, "Niepoprawne dane logowania.", Toast.LENGTH_SHORT).show();
                }

                  /*Login2 login = new Login2();

                  if(loginText.getText()!=null&&passwordText.getText()!=null) {

                      login.setLogin(loginText.getText().toString());
                      login.setPassword(passwordText.getText().toString());

                      try {
                          Worker response = (Worker) new Http_findLogin_Task().execute(login).get();
                          //loginText.setText(((User) response).toString());

                              Toast.makeText(MainActivity.this, response.getName(), Toast.LENGTH_SHORT);



                      } catch (InterruptedException e) {

                          //e.printStackTrace();

                      } catch (ExecutionException e) {

                          //e.printStackTrace();

                      }
                  }
                  else{
                      Toast.makeText(MainActivity.this,"Pola nie mogą być puste",Toast.LENGTH_SHORT).show();
                  }*/


            }
        });
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Toast.makeText(MainActivity.this,"Pola nie mogą być puste",Toast.LENGTH_SHORT).show();
        }

        return super.onOptionsItemSelected(item);
    }

   /* private void launch(Object res){

        //String pos = ((User)res).idSt;
        //UserInfo.login = ((User)res).id;
        UserInfo.user = (User)res;
        String pos = UserInfo.user.idSt;
        if(pos != null) {
            switch (pos) {
                case ("1"):
                    startActivity(new Intent(MainActivity.this, ManagerMain.class));
                    break;
                case ("2"):
                    //startActivity(new Intent(this, WorkerMainActivity.class));
                    //TODO activity obsługujące widok pracownika.
                    break;
                default:
                    break;
            }
        }

    }*/

    private class Http_findLogin_Task extends AsyncTask  {

        @Override
        protected Object doInBackground(Object[] objects) {

            try {
                Worker login = (Worker)objects[0];
                final RestTemplate restTemplate = new RestTemplate();
                restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());

                //String queryURL = UserInfo.urlString + "api/login"; //findLogin?login=" + login.getLogin();
                String queryURL = "https://10.0.2.2:8434/api/login";
                Worker response = restTemplate.postForObject(queryURL, login, Worker.class);
                return response;

            } catch (Exception e) {

                Log.e("MainActivity", e.getMessage(), e);

            }

            return null;

        }
    }
}
