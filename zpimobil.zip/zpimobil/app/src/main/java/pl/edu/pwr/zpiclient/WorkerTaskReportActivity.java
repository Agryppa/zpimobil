package pl.edu.pwr.zpiclient;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class WorkerTaskReportActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_worker_task_report);
    }
}
